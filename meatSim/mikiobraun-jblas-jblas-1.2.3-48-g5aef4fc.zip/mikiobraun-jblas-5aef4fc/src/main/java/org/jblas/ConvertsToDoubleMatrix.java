/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.jblas;

/**
 * EXPERIMENTAL, not yet used for anything usefull... .
 * 
 * @author Mikio L. Braun
 */
public interface ConvertsToDoubleMatrix {
    public DoubleMatrix convertToDoubleMatrix();
}
