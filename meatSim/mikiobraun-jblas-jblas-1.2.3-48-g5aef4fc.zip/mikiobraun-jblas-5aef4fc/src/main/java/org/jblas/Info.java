package org.jblas;

/**
 * <one line description>
 * <p/>
 * <longer description>
 * <p/>
 * User: mikio
 * Date: 2/12/13
 * Time: 3:28 PM
 */
public class Info {
  public static String VERSION = "1.2.3";
}
